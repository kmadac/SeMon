from distutils.core import setup

setup(
    name='SeMon',
    version='0.1',
    packages=['SeMon'],
    url='',
    license='',
    author='Kamil Madac',
    author_email='kamil.madac@gmail.com',
    description='Simle Server Monitoring'
)
